
package lecture10;
public interface IBook {
    void addBook();
    void updateBook(String id);
    void displayBook();
}
